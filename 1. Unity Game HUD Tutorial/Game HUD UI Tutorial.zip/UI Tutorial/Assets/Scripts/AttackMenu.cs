using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MenuScript : MonoBehaviour
{
    public float health = 100f;
    public float score;
    [SerializeField] private TextMeshProUGUI scoreText;
    [SerializeField] private TextMeshProUGUI healthText;
    [SerializeField] private Slider slider;
    [SerializeField] private Button button;

    private void addScore()
    {
        score += 1f;
        scoreText.text = "Score: " + score;
    }

    public void damageHealth(int damage)
    {
        if(health - damage > 0)
        {
            health -= damage;
        }
        else {
            health = 0f;
            addScore();
            resetHealth();
        }

        slider.value = health / 100f;
        updateHealthText();
    }

    private void updateHealthText()
    {
        healthText.text = health + "%";
    }

    private void resetHealth()
    {
        slider.value = 1f;
        health = 100f;
    }

}
